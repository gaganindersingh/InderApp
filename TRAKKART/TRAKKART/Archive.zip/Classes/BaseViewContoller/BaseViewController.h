//
//  ViewController.h
//  TRAKART
//
//  Created by Mac Min on 20/11/14.
//  Copyright (c) 2014 Gaganinder Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
{
    
    __weak IBOutlet UIImageView *imgVwMovingImages;
}

@end

