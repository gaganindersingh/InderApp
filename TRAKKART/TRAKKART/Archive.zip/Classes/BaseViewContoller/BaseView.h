//
//  BaseView.h
//  TRAKART
//
//  Created by Mac Min on 20/11/14.
//  Copyright (c) 2014 Gaganinder Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseView : UIView

@end
