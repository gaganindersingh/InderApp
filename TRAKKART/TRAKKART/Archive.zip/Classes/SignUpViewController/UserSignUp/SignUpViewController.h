//
//  SignUpViewController.h
//  TRAKKART
//
//  Created by Mac Min on 22/11/14.
//  Copyright (c) 2014 Gaganinder Singh. All rights reserved.
//

#import "BaseViewController.h"
@class SignUpView;
@interface SignUpViewController : BaseViewController
{
    
    IBOutlet SignUpView *objSignUpView;
}

-(void)updateSignUpDataValueFromDriverSignUp:(NSMutableDictionary *)dicData;
-(void)deSelectDriverCheckBox;
@end
