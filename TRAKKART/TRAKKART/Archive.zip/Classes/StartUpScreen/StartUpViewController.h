//
//  StartUpViewController.h
//  TRAKKART
//
//  Created by Mac Min on 25/11/14.
//  Copyright (c) 2014 Gaganinder Singh. All rights reserved.
//

#import "BaseViewController.h"
@class StartUpView;
@interface StartUpViewController : BaseViewController
{

    
    IBOutlet StartUpView *objStartUpView;
}
@end
