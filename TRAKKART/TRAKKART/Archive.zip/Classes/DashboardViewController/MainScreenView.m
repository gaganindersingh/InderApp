//
//  MainScreenView.m
//  TRAKKART
//
//  Created by Mac Min on 06/12/14.
//  Copyright (c) 2014 Gaganinder Singh. All rights reserved.
//

#import "MainScreenView.h"
#import "MovingImages.h"
@implementation MainScreenView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
